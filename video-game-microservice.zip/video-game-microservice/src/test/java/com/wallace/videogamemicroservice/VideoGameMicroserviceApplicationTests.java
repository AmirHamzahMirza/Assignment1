package com.wallace.videogamemicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideoGameMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
