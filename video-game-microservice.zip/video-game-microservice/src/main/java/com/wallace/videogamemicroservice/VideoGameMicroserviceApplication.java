package com.wallace.videogamemicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VideoGameMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VideoGameMicroserviceApplication.class, args);
	}

}
